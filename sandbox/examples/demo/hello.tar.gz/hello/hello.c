
#include <stdio.h>

int
main(int _argc, char* _argv[])
{
    printf("Hi!\n");
    return 0;
}


