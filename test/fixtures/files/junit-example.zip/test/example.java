import org.junit.Test;

import edu.neu.TestWeight;

public class ExampleTestClass {
  @TestWeight(weight = 1)
  @Test(timeout=5000)
  public void testNothing() {}
}
