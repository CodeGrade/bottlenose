'''
DS2000
Nicholas Sicurelli
HW4
test_baseball
'''
from baseball import *


TESTREC1 = ['L', 'L', 'L', 'L', 'W']
TESTRUN1 = [6, 6, 6, 6, 1]

TESTREC2 = ['L', 'L', 'L', 'L', 'W']
TESTRUN2 = [1,1,1,1,6]

TESTREC3 = ['L', 'L', 'L', 'L', 'L']
TESTRUN3 = [0,0,0,0,0]

TESTREC4 = ['W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W',
            'W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W',
            'W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W',
            'W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W',
            'W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W',
            'W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W',
            'W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W',
            'W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W',
            'W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W',
            'W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W']
TESTRUN4 = [4, 1, 3, 2, 7, 4, 3, 10, 8, 14, 7, 6, 7, 10, 3, 10, 9, 8, 7, 0,
        1, 3, 4, 5, 3, 6, 4, 10, 6, 5, 5, 5, 6, 6, 2, 6, 5, 3, 5, 5, 5,
        3, 6, 6, 4, 6, 5, 4, 4, 3, 6, 8, 1, 8, 8, 6, 2, 3, 5, 9, 6, 7,
        2, 0, 4, 2, 2, 6, 5, 2, 6, 0, 9, 2, 1, 9, 14, 2, 5, 9, 9, 4, 1,
        11, 1, 4, 11, 3, 10, 15, 7, 5, 8, 4, 6, 7, 6, 5, 1, 0, 9, 5, 6,
        1, 4, 10, 3, 2, 1, 15, 4, 4, 5, 10, 10, 5, 19, 5, 6, 4, 2, 4, 7,
        5, 0, 4, 3, 10, 7, 3, 1, 1, 8, 14, 9, 1, 6, 0, 8, 5, 9, 3, 3, 6,
        7, 1, 4, 0, 5, 4, 2, 1, 11, 7, 4, 3, 6, 19, 3, 6, 5, 10]
def main():
    print('EXPECTED \n 1 wins, 4 losses.\n Average number of runs was 5.0\n The number of wins with only one home run was 1\nThe number of losses with six home runs was 4')
    print ('ACTUAL')
    a = winratio(TESTREC1)
    b = runavg(TESTRUN1)
    c = onerunwin(TESTREC1, TESTRUN1)
    d = sixrunlose(TESTREC1, TESTRUN1, 6)
    if a == [1, 4] and b == 5.0 and c == 1 and d == 4:
        print ("SUCCESS\n")
    else:
        print ("FAILURE\n")



    print('EXPECTED \n 1 wins, 4 losses.\n Average number of runs was 2.0\n The number of wins with only one home run was 0\nThe number of losses with six home runs was 0')
    print ('ACTUAL')
    a = winratio(TESTREC2)
    b = runavg(TESTRUN2)
    c = onerunwin(TESTREC2, TESTRUN2)
    d = sixrunlose(TESTREC2, TESTRUN2, 6)
    if a == [1, 4] and b == 2.0 and c == 0 and d == 0:
        print ("SUCCESS\n")
    else:
        print ("FAILURE\n")
    
    print('EXPECTED \n 0 wins, 5 losses.\n Average number of runs was 0\n The number of wins with only one home run was 0\nThe number of losses with six home runs was 0')
    print ('ACTUAL')
    a = winratio(TESTREC3)
    b = runavg(TESTRUN3)
    c = onerunwin(TESTREC3, TESTRUN3)
    d = sixrunlose(TESTREC3, TESTRUN3, 6)
    if a == [0, 5] and b == 0 and c == 0 and d == 0:
        print ("SUCCESS\n")
    else:
        print ("FAILURE\n")

    print('EXPECTED \n 162 wins, 0 losses.\n Average number of runs was 5.407407407407407\n The number of wins with only one home run was 14\nThe number of losses with six home runs was 0')
    print ('ACTUAL')
    a = winratio(TESTREC4)
    b = runavg(TESTRUN4)
    c = onerunwin(TESTREC4, TESTRUN4)
    d = sixrunlose(TESTREC4, TESTRUN4, 6)
    if a == [162, 0] and b == 5.407407407407407 and c == 14 and d == 0:
        print ("SUCCESS\n")
    else:
        print ("FAILURE\n")






