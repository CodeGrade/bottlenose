'''
DS2000
Nicholas Sicurelli
HW4
Baseball.py
functions
'''

def winratio(data):
    wins = 0
    losses = 0
    for i in data:
        if i == 'W':
            wins += 1
        if i == 'L':
            losses += 1
    print(wins, 'wins,',losses,'losses.')
    return [wins, losses]



def runavg(runs):
    runavg = sum(runs)/len(runs)

    print('Average number of runs was',runavg)
    return runavg

def onerunwin(RECORD,RUNS):
    count = 0
    onerunwins = 0
    while count != len(RUNS):
        if RECORD[count] == 'W' and RUNS[count] == 1:
            onerunwins += 1
            count += 1
        else:
            count += 1
    print ('The number of wins with only one home run was',onerunwins)
    return onerunwins
    
def sixrunlose(RECORD,RUNS,n):
    count = 0
    sixrunlose = 0
    while count != len(RUNS):
        if RECORD[count] == 'L' and RUNS[count] == n:
            sixrunlose += 1
            count += 1
        else:
            count += 1
    print ('The number of losses with six home runs was',sixrunlose)
    return sixrunlose
                  
