'''
DS2000
Nicholas Sicurelli
HW4
sox_viz
'''

import turtle
from sox18 import *


def moveturtle():
    x = 0
    y = 0
    for i in RECORD:
        if i == 'W':
            x = x + 2
            y = y + 4
        else:
            x = x + 2
            y = y - 4
        turtle.goto(x,y)
    return x
def scatter(i):
    count = 0
    while count != len(RUNS):
        if RECORD[count] == 'W':
            color = 'purple'
        else:
            color = 'green'
        y = RUNS[count]
        turtle.penup()
        turtle.goto(i+count*4, y*4)
        turtle.pendown()
        turtle.dot(4,color)
        count = count + 1
def main():
    x = moveturtle()
    scatter(x)
    
